//
//  TwoCardsView.swift
//  FinTech
//
//  Created by ABDULRAHMAN AL-KHALED on 09/11/2023.
//

import SwiftUI

struct TwoCardsView: View {
    var body: some View {
        VStack(spacing: -310){
            ZStack{
                Rectangle()
                    .frame(width: 314, height: 194)
                    .cornerRadius(15)
                    .foregroundStyle(.color1)
                   
                
                VStack{
                    HStack{
                        Image("Image 22")
                            .resizable()
                            .frame(width: 22, height: 22)
                            .offset(CGSize(width: 10.0, height: 10.0))
                        Spacer()
                        Text("This month")
                            .offset(CGSize(width: -20.0, height: 10.0))
                    }.padding(.horizontal,36)
                      
                    HStack{
                        Text("Balance")
                            .bold()
                          //  .frame(maxWidth: .infinity, alignment: .leading)
                            .offset(CGSize(width: 30.0, height: 10.0))
                        Spacer()
                        Image("Image 24")
                            .resizable()
                            .frame(width: 24, height: 24)
                            .offset(CGSize(width: -18.0, height: 10.0))
                        Text("12.884 USD")
                            .font(.subheadline)
                            .offset(CGSize(width: -18.0, height: 10.0))
                    }.padding(.horizontal)
                    HStack{
                        
                        Text("22.866")
                            .bold()
                            .font(.title2)
                            .foregroundStyle(.color)
                            .offset(CGSize(width: 30.0, height: 10.0))
                        Spacer()
                        Image("Image 25")
                            .resizable()
                            .frame(width: 24, height: 24)
                            .offset(CGSize(width: -22.0, height: 10.0))

                        Text("7.449 USD")
                            .font(.subheadline)
                            .offset(CGSize(width: -22.0, height: 10.0))

                    }.padding(.horizontal)
                    
                }.padding(.top)
                
            }
                ZStack{
                    Image("Image 19")
                        .resizable()
                        .frame(width: 301, height: 211)
                    VStack{
                    HStack{
                        Image("Image 20")
                            .resizable()
                            .frame(width: 44, height: 31)
                        // .frame(maxWidth: .infinity, alignment: .leading)
                        
                        Text("A.I. ASHIK")
                            .font(.footnote)
                            .foregroundStyle(.white)
                        Spacer()
                        Image("Image 21")
                            .resizable()
                            .frame(width: 40, height: 13)
                        // .frame(maxWidth: .infinity, alignment: .trailing)
                    }//.padding(.vertical)
                       
                    VStack{
                        Text("**** 2001")
                            .font(.subheadline)
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        HStack{
                            Text("4200.00 USD")
                                .bold()
                                .foregroundStyle(.white)
                            Spacer()
                            Image("Image 23")
                                .resizable()
                                .frame(width: 38, height: 25)
                        }
                        
                    }.padding(.vertical,32)
                    
                }.padding(.horizontal,67)
                    
                }
        

        }  .padding(.horizontal)
    }
}

#Preview {
    TwoCardsView()
}
